const { ethers } = require("hardhat");

async function main() {
  const ChickenNFT = await ethers.getContractFactory("MyriaAsset");

  const chickenNFT = await ChickenNFT.deploy("0xd0D8A467Eb8526C2AF030C18C64A664A5e1aF34A", "Chicken", "ChickenNFT", "0x471bDA7f420de34282AB8AF1F5F3DAf2a4C09746");
  await chickenNFT.deployed();
  console.log("Contract deployed to address:", chickenNFT.address);
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.log(err);
    process.exit(1);
  })