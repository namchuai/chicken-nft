require("dotenv").config();
// const starkwareCrypto = require("./signature/signature.js");

const API_URL = process.env.API_URL;
const PUBLIC_KEY = process.env.PUBLIC_KEY;
const PRIVATE_KEY = process.env.PRIVATE_KEY;
const STARKEX_ADDRESS = process.env.STARKEX_ADDRESS;

console.log(PRIVATE_KEY);
// const keyPair = starkwareCrypto.ec.keyFromPrivate(PRIVATE_KEY, "hex");
// console.log(keyPair);
